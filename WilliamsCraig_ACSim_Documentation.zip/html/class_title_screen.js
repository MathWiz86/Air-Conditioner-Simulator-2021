var class_title_screen =
[
    [ "AwaitAnimation", "class_title_screen.html#a977149847c5387a82bd5a2b2cdf6358d", null ],
    [ "Awake", "class_title_screen.html#a6540648a42e10d3b7274967294a6c9cb", null ],
    [ "HandleTitleScreen", "class_title_screen.html#a44306b0a0f973e3fcede1370c30efb8f", null ],
    [ "titleAnimator", "class_title_screen.html#a65e8d78ae769284ba55d65b5dd9e1969", null ]
];