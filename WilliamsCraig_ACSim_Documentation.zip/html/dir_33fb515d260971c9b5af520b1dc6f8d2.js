var dir_33fb515d260971c9b5af520b1dc6f8d2 =
[
    [ "FuzzyKit.cs", "_fuzzy_kit_8cs.html", [
      [ "FuzzyKit", "class_a_c_sim_1_1_kits_1_1_fuzzy_kit.html", "class_a_c_sim_1_1_kits_1_1_fuzzy_kit" ]
    ] ],
    [ "ReflectionKit.cs", "_reflection_kit_8cs.html", [
      [ "Reflection", "class_a_c_sim_1_1_kits_1_1_reflection.html", "class_a_c_sim_1_1_kits_1_1_reflection" ]
    ] ]
];