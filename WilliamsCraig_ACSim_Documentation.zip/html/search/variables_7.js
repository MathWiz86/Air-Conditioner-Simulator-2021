var searchData=
[
  ['lastfluctuationtoggle_511',['lastFluctuationToggle',['../class_a_c_sim_1_1_u_i_1_1_screens_1_1_settings_screen.html#a896106cff74818c79d9e06b08f98ded0',1,'ACSim::UI::Screens::SettingsScreen']]]
];
