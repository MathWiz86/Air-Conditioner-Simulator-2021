var searchData=
[
  ['phonescreen_300',['PhoneScreen',['../class_a_c_sim_1_1_u_i_1_1_screens_1_1_phone_screen.html',1,'ACSim::UI::Screens']]],
  ['phonesystem_301',['PhoneSystem',['../class_a_c_sim_1_1_systems_1_1_phone_system.html',1,'ACSim::Systems']]]
];
