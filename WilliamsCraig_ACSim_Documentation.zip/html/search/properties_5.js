var searchData=
[
  ['screencanvas_587',['screenCanvas',['../class_a_c_sim_1_1_u_i_1_1_screens_1_1_phone_screen.html#a6ed58ac65d68e2aad2ee7265535614e5',1,'ACSim::UI::Screens::PhoneScreen']]],
  ['slider_588',['slider',['../class_a_c_sim_1_1_u_i_1_1_settings_slider.html#a58b4e19aeaeffbbd1c167a283298d034',1,'ACSim::UI::SettingsSlider']]]
];
