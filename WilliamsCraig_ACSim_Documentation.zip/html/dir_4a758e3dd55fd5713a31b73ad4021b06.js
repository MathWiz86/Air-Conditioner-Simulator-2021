var dir_4a758e3dd55fd5713a31b73ad4021b06 =
[
    [ "CreditsScreen.cs", "_credits_screen_8cs.html", [
      [ "CreditsScreen", "class_a_c_sim_1_1_u_i_1_1_screens_1_1_credits_screen.html", "class_a_c_sim_1_1_u_i_1_1_screens_1_1_credits_screen" ]
    ] ],
    [ "InformationScreen.cs", "_information_screen_8cs.html", [
      [ "InformationScreen", "class_a_c_sim_1_1_u_i_1_1_screens_1_1_information_screen.html", "class_a_c_sim_1_1_u_i_1_1_screens_1_1_information_screen" ],
      [ "TSTriangleInformationDisplay", "class_a_c_sim_1_1_u_i_1_1_screens_1_1_information_screen_1_1_t_s_triangle_information_display.html", "class_a_c_sim_1_1_u_i_1_1_screens_1_1_information_screen_1_1_t_s_triangle_information_display" ]
    ] ],
    [ "MainScreen.cs", "_main_screen_8cs.html", [
      [ "MainScreen", "class_a_c_sim_1_1_u_i_1_1_screens_1_1_main_screen.html", "class_a_c_sim_1_1_u_i_1_1_screens_1_1_main_screen" ]
    ] ],
    [ "PhoneScreen.cs", "_phone_screen_8cs.html", [
      [ "PhoneScreen", "class_a_c_sim_1_1_u_i_1_1_screens_1_1_phone_screen.html", "class_a_c_sim_1_1_u_i_1_1_screens_1_1_phone_screen" ]
    ] ],
    [ "QuitScreen.cs", "_quit_screen_8cs.html", [
      [ "QuitScreen", "class_a_c_sim_1_1_u_i_1_1_screens_1_1_quit_screen.html", null ]
    ] ],
    [ "SettingsScreen.cs", "_settings_screen_8cs.html", [
      [ "SettingsScreen", "class_a_c_sim_1_1_u_i_1_1_screens_1_1_settings_screen.html", "class_a_c_sim_1_1_u_i_1_1_screens_1_1_settings_screen" ]
    ] ],
    [ "ThermostatScreen.cs", "_thermostat_screen_8cs.html", [
      [ "ThermostatScreen", "class_a_c_sim_1_1_u_i_1_1_screens_1_1_thermostat_screen.html", "class_a_c_sim_1_1_u_i_1_1_screens_1_1_thermostat_screen" ]
    ] ]
];